# Function definition
# Sigmoid_surrogate
Sigmoid<-function(x,tau)
{
  return(1/(1+exp(-x/tau)))
}
Sigmoid_d<-function(x,tau)
{
  return(1/(2+exp(-x/tau)+exp(x/tau))/tau)
}

# MCP
MCP<-function(x,lambda,gamma)
{
  
  x_d<-(abs(x)-lambda*gamma)*(abs(x)<lambda*gamma)+lambda*gamma
  return(lambda*x_d-x_d^2/(2*gamma))
}
MCP_d<-function(x,lambda,gamma)
{
  x_d<-(abs(x)-lambda*gamma)*(abs(x)<lambda*gamma)+lambda*gamma
  return(sign(x)*(lambda-x_d/gamma))
}

# ADMM
ADMM_Diff<-function(mu_hat,Eta_hat)
{
  n<-dim(Eta_hat)[1]
  q<-dim(Eta_hat)[3]
  diff_value<-0*Eta_hat
  all_value<-0
  for(i in 1:q)
  {
    diff_value[,,i]<-mu_hat[,i]%*%t(rep(1,n))-t(mu_hat[,i]%*%t(rep(1,n)))-Eta_hat[,,i]
  }
  return(diff_value)
}

##########################################
# Objective function
STCF<-function(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau)
{
  n<-nrow(X)
  p<-ncol(X)
  q<-ncol(mu_hat)
  
  Y_ijil<-matrix(2*X[Set_T[,1],]-X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  Y_jl<-matrix(X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  
  #Eta_hat<-Eta_hat_P-Eta_hat_N
  DiYi<-NULL
  DiEr<-NULL
  for(i in 1:q)
  {
    hai<-Eta_hat[,,q]
    DiYi<-cbind(DiYi,hai[Set_T[,1]+n*Set_T[,2]-n]+hai[Set_T[,1]+n*Set_T[,3]-n])
    DiEr<-cbind(DiEr,hai[Set_T[,2]+n*Set_T[,3]-n])
  }
  
  DiYi<-DiYi+Y_ijil%*%B_hat
  DiEr<-DiEr+Y_jl%*%B_hat
  
  Values<-choose(n,2)*mean(Sigmoid(rowSums(DiYi*DiEr),tau = tau))
  
  Distances<-sqrt(apply(Eta_hat^2,1:2,sum))
  Values<-Values-sum(MCP(Distances,lambda,gamma))/2
  
  diff_value<-ADMM_Diff(mu_hat,Eta_hat)
  Values<-Values-sum(V_hat*diff_value)/2-vartheta/2*sum((diff_value)^2)/2
  
  return(Values)
}

STCF_Eta_update<-function(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau)
{
  n<-nrow(X)
  p<-ncol(X)
  q<-ncol(mu_hat)
  T_size<-nrow(Set_T)
  
  Y_ijil<-matrix(2*X[Set_T[,1],]-X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  Y_jl<-matrix(X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  
  #Eta_hat<-Eta_hat_P-Eta_hat_N
  DiYi<-NULL
  DiEr<-NULL
  for(i in 1:q)
  {
    hai<-Eta_hat[,,q]
    DiYi<-cbind(DiYi,hai[Set_T[,1]+n*Set_T[,2]-n]+hai[Set_T[,1]+n*Set_T[,3]-n])
    DiEr<-cbind(DiEr,hai[Set_T[,2]+n*Set_T[,3]-n])
  }
  
  DiYi<-DiYi+Y_ijil%*%B_hat
  DiEr<-DiEr+Y_jl%*%B_hat
  
  Hn<-choose(n,2)*Sigmoid_d(rowSums(DiYi*DiEr),tau = tau)
  
  d_Eta_hat<-V_hat
  for(i in 1:n)
  {
    for(j in setdiff(1:n,i))
    {
      Y_index<-c(which((Set_T[,1]==i)*(Set_T[,2]==j)==1),which((Set_T[,1]==i)*(Set_T[,3]==j)==1))
      N_index<-c(which((Set_T[,2]==i)*(Set_T[,3]==j)==1))
      
      if((length(Y_index))>0)
      {
        d_Eta_hat[i,j,]<-d_Eta_hat[i,j,]+sum(Hn[Y_index]*DiEr[Y_index,])/T_size
        d_Eta_hat[j,i,]<-d_Eta_hat[j,i,]-sum(Hn[Y_index]*DiEr[Y_index,])/T_size
      }
      
      if((length(N_index))>0)
      {
        d_Eta_hat[i,j,]<-d_Eta_hat[i,j,]+sum(Hn[N_index]*DiYi[N_index,])/T_size
        d_Eta_hat[j,i,]<-d_Eta_hat[j,i,]-sum(Hn[N_index]*DiYi[N_index,])/T_size
      }
    }
  }
  Eta_hat_new<-d_Eta_hat/vartheta+ADMM_Diff(mu_hat,Eta_hat)+Eta_hat
  
  #sign_Eta_hat_new<-sign(Eta_hat_new)
  #Abs_Eta_hat_new<-abs(Eta_hat_new)
  #Abs_Eta_hat_new_adjust<-(Abs_Eta_hat_new-lambda/vartheta)*(Abs_Eta_hat_new>lambda/vartheta)
  #Eta_hat_adjust<-sign_Eta_hat_new*(Abs_Eta_hat_new_adjust)/(1-1/(gamma*vartheta))
  
  LL<-sqrt(apply(Eta_hat_new^2,1:2,sum))+0.001
  LL_adjust<-(LL-lambda/vartheta)*(LL>lambda/vartheta)/(1-1/(gamma*vartheta))
  ratio_LL<-LL_adjust/LL
  ratio_LL<-1+(ratio_LL-1)*(ratio_LL<1)
  
  for(s in 1:q)
  {Eta_hat_new[,,s]<-Eta_hat_new[,,s]*ratio_LL}
  return(Eta_hat_new)
}

STCF_Mu_update<-function(mu_hat,Eta_hat,V_hat,vartheta)
{
  n<-nrow(mu_hat)
  YY<-apply(Eta_hat-V_hat/vartheta,c(1,3),sum)
  YY<-YY-rep(1,n)%*%t(colMeans(YY))
  mu_hat_new<-YY/n
  return(mu_hat_new)
}

STCF_V_update<-function(mu_hat,Eta_hat,V_hat,vartheta)
{
  V_hat_new<-V_hat+vartheta*ADMM_Diff(mu_hat,Eta_hat)
  return(V_hat_new)
}

STCF_beta_value<-function(beta_hat,Eta_hat,X,Set_T,tau)
{
  n<-nrow(X)
  p<-ncol(X)
  B_hat<-matrix(beta_hat,nrow = p)
  q<-ncol(B_hat)
  
  Y_ijil<-matrix(2*X[Set_T[,1],]-X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  Y_jl<-matrix(X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  
  #Eta_hat<-Eta_hat_P-Eta_hat_N
  #Eta_hat<-Eta_hat_P-Eta_hat_N
  DiYi<-NULL
  DiEr<-NULL
  for(i in 1:q)
  {
    hai<-Eta_hat[,,q]
    DiYi<-cbind(DiYi,hai[Set_T[,1]+n*Set_T[,2]-n]+hai[Set_T[,1]+n*Set_T[,3]-n])
    DiEr<-cbind(DiEr,hai[Set_T[,2]+n*Set_T[,3]-n])
  }
  
  DiYi<-DiYi+Y_ijil%*%B_hat
  DiEr<-DiEr+Y_jl%*%B_hat
  
  Values<-mean(Sigmoid(rowSums(DiYi*DiEr),tau = tau))-sum(beta_hat^2)
  
  return(Values)
}

STCF_beta_gradient<-function(beta_hat,Eta_hat,X,Set_T,tau)
{
  n<-nrow(X)
  p<-ncol(X)
  B_hat<-matrix(beta_hat,nrow = p)
  q<-ncol(B_hat)
  T_size<-nrow(Set_T)
  
  Y_ijil<-matrix(2*X[Set_T[,1],]-X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  Y_jl<-matrix(X[Set_T[,2],]-X[Set_T[,3],],ncol = p)
  
  #Eta_hat<-Eta_hat_P-Eta_hat_N
  DiYi<-NULL
  DiEr<-NULL
  for(i in 1:q)
  {
    hai<-Eta_hat[,,q]
    DiYi<-cbind(DiYi,hai[Set_T[,1]+n*Set_T[,2]-n]+hai[Set_T[,1]+n*Set_T[,3]-n])
    DiEr<-cbind(DiEr,hai[Set_T[,2]+n*Set_T[,3]-n])
  }
  
  DiYi<-DiYi+Y_ijil%*%B_hat
  DiEr<-DiEr+Y_jl%*%B_hat
  
  Hn<-Sigmoid_d(rowSums(DiYi*DiEr),tau = tau)/T_size
  
  
  GB<-(-2)*B_hat
  for(i in 1:q)
  {
    GB[,i]<-GB[,i]+colSums(Hn*((Y_ijil)*DiEr[,i]+(Y_jl)*DiYi[,i]))
  }
  
  Grdient_hat<-as.vector(GB)
  return(Grdient_hat)
}
