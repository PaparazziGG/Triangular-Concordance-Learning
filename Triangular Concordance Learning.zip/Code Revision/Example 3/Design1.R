Parallel_N<-function(cishu)
{
  library(abind)
  source("Objective2.R")
  #set.seed(67)
  
  n<-100
  p<-10
  q<-2
  K<-3
  membership<-c(rep(1,0.5*n),rep(2,0.3*n),rep(3,0.2*n))
  
  B<-t(matrix(c(1,-1,1,0,0,1,1,1,rep(0,2*p-8))*1.25,q,p))/2
  #X<-matrix(rnorm(n*p),n,p)
  
  mu<-t(matrix(c(2,0,-4/3,2,-4/3,-2),q,K))
  mu<-mu[membership,]
  
  Result<-NULL
  for(iter in 1:cishu)
  {
    X<-matrix(rnorm(n*p),n,p)
    Z<-X%*%B+mu
    #degree_max<-rbinom(n,n-2,0.)+1
    
    dist_Z<-as.matrix(dist(Z,upper = T,diag = T))
    A<-0*dist_Z
    CV_group<-0*dist_Z
    
    for(i in 1:(n-1))
    {
      for(j in (i+1):n)
      {
        A[i,j]<-rbinom(1,1,median(c(0,1,(3-dist_Z[i,j])/2)))
        A[j,i]<-A[i,j]
        
        #CV_group[i,j]<-sample(1:5,1)
        #CV_group[j,i]<-CV_group[i,j]
        #if(A[i,j]==1)
        #{
        #  segments(Z[i,1],Z[i,2],Z[j,1],Z[j,2],col="grey33")
        #}
      }
    }
    
    #dist_A<-dist_network(A)
    
    AA<-A%*%t(A)+(1-A)%*%t(1-A)
    colmean_AA<-colMeans(AA)
    rowmean_AA<-rowMeans(AA)
    mean_AA<-mean(AA)
    AA<-AA-rep(1,n)%*%t(colmean_AA)-rowmean_AA%*%t(rep(1,n))+mean_AA
    eigen_A<-eigen(AA)
    Z_initial<-eigen_A$vectors[,1:q]%*%diag(sqrt(eigen_A$values[1:q]))
    
    hei<-matrix(0,3,3)
    for(i in 1:3)
    {
      for(j in 1:3)
      {
        hei[i,j]<-mean(A[membership==i,membership==j])
      }
    }
    
    # Sample 8
    Set_T<-NULL
    #Set_CV<-list(NULL,NULL,NULL,NULL,NULL)
    W_T<-NULL
    #W_CV<-list(NULL,NULL,NULL,NULL,NULL)
    shu<-ceiling(sqrt(n))
    for(i in 1:n)
    {
      YY<-which(A[i,]==1)
      NN<-setdiff(which(A[i,]==0),i)
      YYS<-sample(YY,min(c(shu,length(YY))))
      NNS<-sample(NN,min(c(shu,length(NN))))
      CV_group[i,YYS]<-1
      CV_group[i,NNS]<-1
      CV_group[YYS,i]<-1
      CV_group[NNS,i]<-1
      for(j in YYS)
      {
        for(l in NNS)
        {
          Set_T<-rbind(Set_T,c(i,j,l))
          W_T<-c(W_T,1)
        }
      }
    }
    
    inverse_XX<-solve(t(X)%*%X)
    
    ############## Initialization
    ############## Initialization
    lambda_candidate<-0:15/5
    B_hat0<-inverse_XX%*%t(X)%*%Z_initial
    mu_hat0<-Z_initial-X%*%B_hat0
    Eta_hat0<-array(0,dim=c(n,n,q))
    for(i in 1:q)
    {
      Eta_hat0[,,i]<-mu_hat0[,i]%*%t(rep(1,n))-t(mu_hat0[,i]%*%t(rep(1,n)))
    }
    
    B_collection<-NULL
    Mu_collection<-NULL
    Z_collection<-NULL
    
    ############################################### Determinisitic Annealing
    #conv_d<-choose(n,2)*0.001
    lambda<-lambda_candidate[1]
    
    mu_hat<-mu_hat0
    B_hat<-B_hat0
    Eta_hat<-Eta_hat0
    #B_hat<-matrix(rnorm(p*q),nrow = p)
    
    V_hat<-0*Eta_hat#+1
    
    # Penalty
    vartheta<-1
    #lambda<-
    gamma<-2
    tau_trace<-2^(5:(-1)/2)*sqrt(30/n)
    
    #ADMM_Diff(mu_hat,Eta_hat)
    
    #Eta<-array(0,dim=c(n,n,q))
    #mu<-mu[membership,]
    #for(i in 1:q)
    #{
    #  Eta[,,i]<-mu[,i]%*%t(rep(1,n))-t(mu[,i]%*%t(rep(1,n)))
    #}
    #STCF(mu,B,Eta,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1)
    #(Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1))
    #STCF_beta_value(as.vector(B),Eta,X,Set_T,tau=1)
    
    
    for(tau_l in tau_trace)
    {
      mu_hat<-mu_hat/2^(1/2)
      B_hat<-B_hat/2^(1/2)
      Eta_hat<-Eta_hat/2^(1/2)
      V_hat<-V_hat/2^(1/2)
      
      Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_l)
      Value_old<-Value_new-choose(n,2)*0.002
      #Value_ultimate<-STCF(mu,B,Eta,0*Eta,X,vartheta=1,lambda=0,gamma=1.5,Set_T,tau=tau_l)
      
      yaya<-0
      
      while((abs(Value_new-Value_old)>(choose(n,2)*0.001))&(yaya<500))
      {
        yaya<-yaya+1
        Value_old<-Value_new
        # Update B_hat
        beta_hat<-as.vector(B_hat)
        Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1)
        beta_hat_new<-optim(beta_hat,STCF_beta_value,STCF_beta_gradient,Eta_hat=Eta_hat,X=X,Set_T=Set_T,tau=tau_l,method="BFGS",control = list(maxit=3,fnscale=-1))
        #c(Ai,beta_hat_new$value)
        B_hat<-matrix(beta_hat_new$par,nrow = p)
        
        # Update Eta_hat
        Eta_hat<-STCF_Eta_update(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_l)
        #Value_new_new<-STCF(mu_hat,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        # Update mu_hat
        mu_hat<-STCF_Mu_update(mu_hat,Eta_hat,V_hat,vartheta)
        #Value_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        #(Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1))
        
        # Update V_hat
        V_hat<-STCF_V_update(mu_hat,Eta_hat,V_hat,vartheta)
        #Value_new_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat_new,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_l)
        
        print(c(tau_l,Value_new,Value_old))
      }
      
    }
    #plot(mu_hat,pch=18,col=membership+1,cex=2)
    #plot(mu,pch=18,col=membership+1,cex=2)
    #ADMM_Diff(mu_hat,Eta_hat)
    mu_hat0<-mu_hat
    B_hat0<-B_hat
    
    BB<-t(B_hat0)%*%B_hat0
    QBB<-eigen(BB)
    #t(QBB$vectors)%*%BB%*%QBB$vectors
    
    B_hat0<-B_hat0%*%QBB$vectors
    mu_hat0<-mu_hat0%*%QBB$vectors
    #plot(mu_hat0,pch=18,col=membership+1,cex=2)
    #plot(mu,pch=18,col=membership+1,cex=2)
    
    tau_n<-tau_l
    
    ############################## Tuning parameters selection
    
    for(lambda in lambda_candidate)
    {
      mu_hat<-mu_hat0
      B_hat<-B_hat0
      #B_hat<-matrix(rnorm(p*q),nrow = p)
      Eta_hat<-array(0,dim=c(n,n,q))
      for(i in 1:q)
      {
        Eta_hat[,,i]<-mu_hat[,i]%*%t(rep(1,n))-t(mu_hat[,i]%*%t(rep(1,n)))
      }
      V_hat<-0*Eta_hat#+1
      
      # Penalty
      #vartheta<-1
      #lambda<-
      #gamma<-3
      
      #ADMM_Diff(mu_hat,Eta_hat)
      
      #Eta<-array(0,dim=c(n,n,q))
      #mu<-mu[membership,]
      #for(i in 1:q)
      #{
      #  Eta[,,i]<-mu[,i]%*%t(rep(1,n))-t(mu[,i]%*%t(rep(1,n)))
      #}
      #STCF(mu,B,Eta,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1)
      #(Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1))
      #STCF_beta_value(as.vector(B),Eta,X,Set_T,tau=1)
      
      
      Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_n)
      Value_old<-Value_new-choose(n,2)*0.002
      #(Ai<-STCF_beta_value(as.vector(B_hat),Eta_hat,X,Set_T,tau=1))
      #(Ai<-STCF_beta_value(as.vector(B),Eta,X,Set_T,tau=1))
      #print(Value_new)
      #STCF(mu,B,Eta,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1)
      yaya<-0
      
      while((abs(Value_new-Value_old)>(choose(n,2)*0.001))&(yaya<1000))
      {
        yaya<-yaya+1
        Value_old<-Value_new
        # Update B_hat
        beta_hat<-as.vector(B_hat)
        #Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1)
        beta_hat_new<-optim(beta_hat,STCF_beta_value,STCF_beta_gradient,Eta_hat=Eta_hat,X=X,Set_T=Set_T,tau=tau_n,method="BFGS",control = list(maxit=3,fnscale=-1))
        #c(Ai,beta_hat_new$value)
        B_hat<-matrix(beta_hat_new$par,nrow = p)
        
        # Update Eta_hat
        Eta_hat<-STCF_Eta_update(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_n)
        #Value_new_new<-STCF(mu_hat,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        # Update mu_hat
        mu_hat<-STCF_Mu_update(mu_hat,Eta_hat,V_hat,vartheta)
        #Value_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        #(Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1))
        
        # Update V_hat
        V_hat<-STCF_V_update(mu_hat,Eta_hat,V_hat,vartheta)
        #Value_new_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat_new,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
        
        Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=tau_n)
        
        #print(c(lambda,Value_new))
      }
      
      mu_hat0<-mu_hat
      B_hat0<-B_hat
      BB<-t(B_hat0)%*%B_hat0
      QBB<-eigen(BB)
      #t(QBB$vectors)%*%BB%*%QBB$vectors
      
      B_hat0<-B_hat0%*%QBB$vectors
      mu_hat0<-mu_hat0%*%QBB$vectors
      
      B_collection<-abind(B_collection,B_hat0,along = 3)
      Mu_collection<-abind(Mu_collection,mu_hat0,along = 3)
      Z_collection<-abind(Z_collection,X%*%B_hat0+mu_hat0,along = 3)
      #plot(mu_hat0,pch=18,col=membership+1,cex=2)
      #plot(mu_hat,pch=18,col=membership+1,cex=2)
      
    }
    
    
    
    Ya<-cbind(lambda_candidate,0)
    for(a in 1:(dim(B_collection)[3]))
    {
      Mu_collection[,,a]<-Mu_collection[,,a]*sign(B_collection[1,1,a])
      B_collection[,,a]<-B_collection[,,a]*sign(B_collection[1,1,a])
      Z_collection[,,a]<-Z_collection[,,a]*sign(B_collection[1,1,a])
      
      Dist_Za<-as.matrix(dist(Z_collection[,,a],upper = T,diag = T))
      
      denomiators<-(sum(CV_group==0)-n)/2
      enumerator<-0
      for(i in 1:(n-1))
      {
        for(j in (i+1):n)
        {
          if(CV_group[i,j]==0)
          {
            train_1<-c(Dist_Za[i,which((A[i,]==1)*(CV_group[i,]==1)==1)],Dist_Za[j,which((A[j,]==1)*(CV_group[j,]==1)==1)])
            train_0<-c(Dist_Za[i,which((A[i,]==0)*(CV_group[i,]==1)==1)],Dist_Za[j,which((A[j,]==0)*(CV_group[j,]==1)==1)])
            pred<-as.integer((mean(Dist_Za[i,j]<train_1)-mean(Dist_Za[i,j]>train_0))>0)
            enumerator<-enumerator+(pred==A[i,j])
          }
          
        }
        Ya[a,2]<-enumerator/denomiators
      }
    }
    
    Ya[,2]<-Ya[,2]-(Ya[nrow(Ya),2]-Ya[1,2])*(1:nrow(Ya)-1)/(nrow(Ya)-1)
    
    max_pred<-nrow(Ya)+1-(which.max(Ya[nrow(Ya):1,2]))
    
    lambda_choose<-lambda_candidate[max_pred]
    
    ################################### Final fit
    
    mu_hat<-Mu_collection[,,max_pred]
    B_hat<-B_collection[,,max_pred]
    #B_hat<-matrix(rnorm(p*q),nrow = p)
    Eta_hat<-array(0,dim=c(n,n,q))
    for(i in 1:q)
    {
      Eta_hat[,,i]<-mu_hat[,i]%*%t(rep(1,n))-t(mu_hat[,i]%*%t(rep(1,n)))
    }
    V_hat<-0*Eta_hat#+1
    
    # Penalty
    #vartheta<-1
    #lambda<-
    #gamma<-3
    
    #ADMM_Diff(mu_hat,Eta_hat)
    
    #Eta<-array(0,dim=c(n,n,q))
    #mu<-mu[membership,]
    #for(i in 1:q)
    #{
    #  Eta[,,i]<-mu[,i]%*%t(rep(1,n))-t(mu[,i]%*%t(rep(1,n)))
    #}
    #STCF(mu,B,Eta,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1)
    #(Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1))
    #STCF_beta_value(as.vector(B),Eta,X,Set_T,tau=1)
    
    
    Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda=lambda_choose,gamma,Set_T,tau=tau_n)
    Value_old<-Value_new-choose(n,2)*0.002
    #(Ai<-STCF_beta_value(as.vector(B_hat),Eta_hat,X,Set_T,tau=1))
    #(Ai<-STCF_beta_value(as.vector(B),Eta,X,Set_T,tau=1))
    #print(Value_new)
    #STCF(mu,B,Eta,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1)
    yaya<-0
    
    while((abs(Value_new-Value_old)>(choose(n,2)*0.001))&(yaya<500))
    {
      yaya<-yaya+1
      Value_old<-Value_new
      # Update B_hat
      beta_hat<-as.vector(B_hat)
      #Ai<-STCF_beta_value(beta_hat,Eta_hat,X,Set_T,tau=1)
      beta_hat_new<-optim(beta_hat,STCF_beta_value,STCF_beta_gradient,Eta_hat=Eta_hat,X=X,Set_T=Set_T,tau=tau_n,method="BFGS",control = list(maxit=3,fnscale=-1))
      #c(Ai,beta_hat_new$value)
      B_hat<-matrix(beta_hat_new$par,nrow = p)
      
      # Update Eta_hat
      Eta_hat<-STCF_Eta_update(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda_choose,gamma,Set_T,tau=tau_n)
      #Value_new_new<-STCF(mu_hat,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
      
      # Update mu_hat
      mu_hat<-STCF_Mu_update(mu_hat,Eta_hat,V_hat,vartheta)
      #Value_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
      
      #(Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda,gamma,Set_T,tau=1))
      
      # Update V_hat
      V_hat<-STCF_V_update(mu_hat,Eta_hat,V_hat,vartheta)
      #Value_new_new_new_new<-STCF(mu_hat_new,B_hat,Eta_hat_new,V_hat_new,X,vartheta,lambda,gamma,Set_T,tau=3/sqrt(30))
      
      Value_new<-STCF(mu_hat,B_hat,Eta_hat,V_hat,X,vartheta,lambda_choose,gamma,Set_T,tau=tau_n)
      
      #print(c(lambda,Value_new))
    }
    BB<-t(B_hat)%*%B_hat
    QBB<-eigen(BB)
    #t(QBB$vectors)%*%BB%*%QBB$vectors
    
    B_hat<-B_hat%*%QBB$vectors
    mu_hat<-mu_hat%*%QBB$vectors
    
    Result<-rbind(Result,t(rbind(mu_hat,B_hat,rep(lambda_choose,q))))
  }
  return(Result)
}

library(foreach)
library(doParallel)

cl <- makeCluster(20)
registerDoParallel(cl)

# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"Design1a.csv")

cl <- makeCluster(20)
registerDoParallel(cl)

# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"Design1b.csv")

cl <- makeCluster(20)
registerDoParallel(cl)

# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"Design1c.csv")

cl <- makeCluster(20)
registerDoParallel(cl)

# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"Design1d.csv")

cl <- makeCluster(20)
registerDoParallel(cl)

# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"Design1e.csv")