Hai<-read.csv("MMSBM_Lawyer.csv",header = T)[,-1]
AUC_value<-NULL
ww<-c(1,rep(2,99),1)
plot(0,0,type="n",xlim=c(1,0),ylim=c(0,1),xlab = "",ylab = "",main = "")
title(main = "Prediction ROC",cex.main=3)
mtext("Sensitivity",side = 1,cex=2,line = 2.5)
mtext("Specificity",side = 2,cex=2,line = 2.5)
for(j in 0:99)
{for(i in 1:100)
{
  segments(Hai[1+j*2,i],Hai[2+j*2,i],Hai[1+j*2,i+1],Hai[2+j*2,i+1],col=gray(0.5))
}
AUC_value<-c(AUC_value,weighted.mean(Hai[1+j*2,]+Hai[2+j*2,]-1,w=ww)+1/2)}
text(0.4,0.2,paste(c("AUC:",as.character(round(mean(AUC_value),2))),collapse = ""),cex=3)


Hai<-read.csv("MMSBM_Lawyer.csv",header = T)[,-1]
AUC_value<-NULL
ww<-c(1,rep(2,99),1)
png("MMSBM_Lawyer.png",600,600)
plot(0,0,type="n",xlim=c(1,0),ylim=c(0,1),xlab = "",ylab = "",main = "")
title(main = "Prediction ROC",cex.main=3)
mtext("Sensitivity",side = 1,cex=2,line = 2.5)
mtext("Specificity",side = 2,cex=2,line = 2.5)
abline(a=1,b=-1)
library(abind)
YY<-NULL
for(j in 0:99)
{
  YY<-abind(YY,Hai[1:2+j*2,],along=3)
  AUC_value<-c(AUC_value,weighted.mean(Hai[1+j*2,]+Hai[2+j*2,]-1,w=ww)+1/2)
  for(i in 1:100)
  {
    segments(Hai[1+j*2,i],Hai[2+j*2,i],Hai[1+j*2,i+1],Hai[2+j*2,i+1],col=gray(0.85))
  }
}
mean_YY<-apply(YY,1:2,mean)
l_YY<-apply(YY,1:2,quantile,prob=0.025)
m_YY<-apply(YY,1:2,quantile,prob=1-0.025)
#cons_value<-qnorm(0.975)

lines(mean_YY[1,],mean_YY[2,],col=1,lwd=2)
lines(l_YY[1,],l_YY[2,],col=1,lty=2,lwd=2)
lines(m_YY[1,],m_YY[2,],col=1,lty=2,lwd=2)
  
  #l_AUC<-as.character(round(mean(AUC_value)-cons_value*sd(AUC_value),2))
  #u_AUC<-as.character(round(mean(AUC_value)+cons_value*sd(AUC_value),2))
  #text(0.2,0.2,paste(c("AUC:",l_AUC,"-",u_AUC),collapse = "")) 
  
  l_AUC<-as.character(round(quantile(AUC_value,0.025),2))
  u_AUC<-as.character(round(quantile(AUC_value,1-0.025),2))
  text(0.4,0.2,paste(c("AUC:",l_AUC,"-",u_AUC),collapse = ""),cex=3) 
  
  legend("bottomright",legend = c("Mean","95% confidence interval"),lty=1:2,col=1,lwd=2,cex=1.5)
  dev.off()
  mean(AUC_value)